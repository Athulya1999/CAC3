from flask import Flask, request, render_template
import pyodbc

app = Flask(__name__) #creating the Flask class object   
 

cnxn = pyodbc.connect('Driver={SQL Server};'
                      'Server=ATHULYA_PC;'
                      'Database=TEXTILE;'
                      'Trusted_Connection=yes;');
@app.route("/")  
def indexPage():
    mycursor = cnxn.cursor()
    mycursor.execute("select * from textile_details")
    data = mycursor.fetchall()
    return render_template("index.html",data=data)

@app.route("/add", methods=['POST', 'GET'])  
def add(): 
    if request.method == "POST":
        Cutomerid = request.form['Cutomerid']
        name = request.form['name']
        place = request.form['place']
        phone = request.form['phone']
        email = request.form['email']
        with cnxn as conn:
            with conn.cursor() as cursor:
                cursor.execute("INSERT INTO textile_details VALUES (?, ?, ?, ?, ?)", (Cutomerid, name, place, phone, email))
            return render_template("add.html")
    else:
        return render_template('add.html')  

@app.route("/fetch", methods=['POST', 'GET'])
def fetch():
    if request.method == "POST":
        Cutomerid = request.form['Cutomerid']
        
        with cnxn as conn:
            with conn.cursor() as cursor:
                cursor.execute( "SELECT * FROM textile_details WHERE Cutomerid = ?" ,(Cutomerid) )
                data = cursor.fetchall()
            return render_template("index.html", data=data)
    else:
        return render_template("fetch.html")

if __name__ == '__main__':
    app.debug = True
    app.run()